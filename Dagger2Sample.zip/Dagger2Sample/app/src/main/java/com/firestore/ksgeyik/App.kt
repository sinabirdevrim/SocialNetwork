package com.firestore.ksgeyik

import android.app.Application

class App : Application() {

}